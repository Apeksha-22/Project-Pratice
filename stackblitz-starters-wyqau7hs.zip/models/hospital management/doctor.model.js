import mongoose from 'mongoose'

const doctorSchema = new mongoose({
  name:{
    type:String,
    required:true,
    unique:true
  },
  qualification:{
    type:String,
    requied:true,
    unique:true
  },
  workIn:{
    type:mongoose.Types.ObjectId,
    ref:"Hospital",
    required:true
  },
  address:{
    type:String,
    required:true
  },
  phoneNo:{
    type:String,
    required:true
  },
  experience:{
    type:String,
    required:true
  },
  salary:{
    type:String,
    required:true
  },
  duty:{
    type:String,
    required:true
  }
},{timestamps:true});

export const Doctor = mongoose.model("Doctor",doctorSchema);
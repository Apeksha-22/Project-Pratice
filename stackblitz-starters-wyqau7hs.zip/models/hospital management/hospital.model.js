import mongoose from 'mongoose'

const hospitalSchema = new mongoose({
  name:{
    type:String,
    reuired:true,
    unique:true
  },
  address:{
    type:String,
    required:true,
  },
  city:{
    type:String,
    required:true,
  },
  pincode:{
    type:String,
    required:true,
  },
  medicalReports:{
    type:mongoose.Types.ObjectID,
    ref:"Record",
    required:true,
  },
  timing:{
    type:String,
    required:true,
  },
  doctors:{
    type:mongoose.Type.ObjectId,
    ref:"Doctor",
    required:true,
  },
  rooms:{
    type:Number,
    required:true
  },
  fees:{
    type:String,
    required:true
  },
  specilization:{
    type:String,
    required:true
  },
  availableBG:{
    type:String,
    required:true
  }
},{timestamps:true});

export const Hospital = mongoose.model("Hospital",hospitalSchema);
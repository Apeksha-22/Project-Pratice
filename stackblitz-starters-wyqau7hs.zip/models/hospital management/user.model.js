import mongoose from 'mongoose'

const patientSchenma = new mongoose({
  name:{
    type:String,
    required:true,
    unique: true,
  },
  email:{
    type:String,
    required:true,
    unique: true,
    lowecase:true
  },
  password:{
    type:String,
    required:true,
    unique: true,
  },
  diagonsedWith:{
    type:String,
    required:true
  },
  address:{
    type:String,
    required:true
  },
  age:{
    type:Number,
    required:true
  },
  bloodGrp:{
    type: [
      "A+",
      "A-",
      "B+",
      "B-",
      "AB+",
      "AB-",
      "O+",
      "O-"
    ],
    required:true
  },
  medicalHistory:{
    type:String,
    required:true
  },
  gender:{
    type:["Male","Female","Other"],
    required:true
  },
  admittedIn:{
    type:mongoose.Types.ObjectId,
    ref:"Hospital"
  },
  phoneNo:{
    type:String,
    required:true
  }
},{timestamps:true});

export const Patient = mongoose.model("Patient",patientSchenma);
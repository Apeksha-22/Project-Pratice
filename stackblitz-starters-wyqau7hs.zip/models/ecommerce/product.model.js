import mongoose from 'mongoose'

const productSchema = new mongoose.Schema({
  description:{
    type:String,
    required:true,
    lowercase:true
  },
  name:{
    type:String,
    reqired:true
  },
  photoImg:{
    type:String
  },
  price:{
    type:Number,
    default:0
  },
  stock:{
    type:Number,
    default:0
  },
  category:{
    type:mongoose.Schema.Types.ObejctId,
    ref:"Category",
    required:true
  },
  owner:{
    type:mongoose.Schema.Types.ObejctId,
    ref:"User"
  }
},{timestamps:true});

export const Product = mongoose.model('Product',productSchema);
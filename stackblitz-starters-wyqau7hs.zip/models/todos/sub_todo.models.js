import mongoose from 'mongoose'

const subTodoSchema = new mongoose.Schema({});

export const subTodo = mongoose.model("SubTodo", subTodoSchema);
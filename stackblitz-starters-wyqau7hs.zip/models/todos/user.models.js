import mongoose from 'mongoose';

const userSchema = new mongoose.Schema(
  {
    username: {
      type: String,
      required: true, // fixed "requried" typo
      unique: true,
      lowercase: true,
    },
    email: {
      type: String,
      required: true, // fixed "requried" typo
      unique: true,
      lowercase: true,
    },
    password: {
      type: String,
      required: true, // fixed "requried" typo
      unique: true, // Consider removing this as passwords are usually not unique
    },
  },
  { timestamps: true }
);

export const user = mongoose.model('User', userSchema);
